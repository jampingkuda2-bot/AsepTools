# Toolkit — Website Multi Fungsi

Satu website, empat tools, model "home screen" ala iOS — buka web-nya, ketuk ikon tool yang mau dipakai.

| Tool | Fungsi | Diproses di |
|---|---|---|
| 🎵 TikTok DL | Download video TikTok tanpa watermark (MP4/MP3) | Server (Vercel Function) |
| 🗜️ Kompres & Konversi | Kompres/konversi gambar, video, audio | Browser (client-side) |
| 📐 Resize Gambar | Ubah ukuran/dimensi gambar | Browser (client-side) |
| ▦ QR Code | Bikin QR code dari teks/link | Browser (client-side) |

Cuma fitur TikTok Downloader yang butuh proses di server (karena harus ambil data dari API pihak ketiga tikwm.com yang gak bisa diakses langsung dari browser). Tiga tools lainnya 100% jalan di HP/browser pengguna — gak ada data yang keupload ke mana pun.

## Cara Deploy (sama kayak project-project sebelumnya)

1. Upload semua isi folder ini ke repo GitHub (bisa timpa repo TikTok downloader yang lama, atau bikin repo baru)
2. vercel.com → login GitHub → **Add New → Project** → pilih repo ini → **Deploy**
3. Selesai, dapat link publik `https://nama-project.vercel.app`

Gak ada environment variable yang perlu diisi.

## Struktur

```
toolkit-web/
├── index.html          # semua screen (home + 4 tool) dalam satu halaman
├── style.css            # UI glass iOS terpadu buat semua tool
├── app.js               # navigasi antar screen + inisialisasi semua tool
├── tools/
│   ├── tiktok.js         # logic TikTok downloader
│   ├── compress.js       # logic kompres/konversi (Canvas + FFmpeg.wasm)
│   ├── resize.js         # logic resize gambar (Canvas)
│   └── qrcode.js          # logic QR code generator
├── api/
│   ├── info.js           # [server] ambil metadata TikTok
│   └── download.js       # [server] redirect MP4 / convert MP3
├── lib/
│   ├── tiktokApi.js
│   └── media.js
└── vercel.json           # setting durasi function buat TikTok downloader
```

## Nambah tool baru nanti
Polanya konsisten: bikin 1 file baru di `tools/nama-tool.js` yang export `initNamaTool()`, tambahin section HTML-nya di `index.html` (contoh section yang sudah ada bisa dicontoh), tambahin 1 ikon baru di `.app-grid`, lalu import & panggil di `app.js`. Kalau butuh tool baru, tinggal bilang aja fungsinya apa.

## Batasan
- Sama seperti sebelumnya: Vercel Hobby plan gratis untuk pemakaian pribadi/non-komersial.
- Kompres/konversi video besar (>250MB) bisa berat diproses karena jalan di device pengguna sendiri (ada peringatan otomatis; di atas 700MB langsung ditolak karena hampir pasti bikin HP crash kehabisan memori).
- Kalau API tikwm.com berubah/down, sesuaikan `lib/tiktokApi.js`.

## 🔐 Fitur Baru: Login (Email/Password + Google)

Sekarang ada halaman login di depan — orang harus Masuk/Daftar dulu sebelum bisa pakai tools-nya.

**Wajib disiapkan di Vercel supaya login jalan:**

1. **Database akun** — Vercel udah pensiunin produk "KV" bawaan, sekarang lewat **Marketplace**. Di dashboard project → tab **Storage** → **Browse Storage** → pilih **Upstash** (Serverless DB Redis) → bikin database Redis → connect ke project ini. Env variable yang dibutuhkan kode ini (`KV_REST_API_URL`, `KV_REST_API_TOKEN`, dst) otomatis ke-set, gak perlu diisi manual.
2. **JWT_SECRET** — di **Settings → Environment Variables**, tambah `JWT_SECRET` = string acak panjang (buat sendiri, misal 32+ karakter). Ini buat menandatangani sesi login biar aman.
3. **(Opsional) Login Google** — biar tombol "Lanjutkan dengan Google" aktif:
   - Ke [Google Cloud Console](https://console.cloud.google.com/) → buat project → **APIs & Services → Credentials → Create Credentials → OAuth client ID** (tipe: Web application).
   - Authorized redirect URI: `https://nama-project-kamu.vercel.app/api/auth/google/callback`
   - Salin **Client ID** & **Client Secret**, tambahkan sebagai env var `GOOGLE_CLIENT_ID` dan `GOOGLE_CLIENT_SECRET` di Vercel.

Kalau Google belum di-setup, tombolnya tetap muncul tapi kasih pesan error yang jelas kalau diklik — login email/password tetap jalan normal asal database + JWT_SECRET sudah ada.

Setelah ubah/tambah environment variable, **redeploy** project-nya biar keambil.

## 🔗 Fitur Baru: Foto/Video ke Link

Upload foto atau video (maks 500MB), dapat link yang bisa dibuka siapa aja (gak perlu login/akun) buat lihat/download filenya. File disimpan pakai **Vercel Blob** biar upload video besar gak kena limit ukuran request server (upload langsung dari browser ke storage).

**Wajib disiapkan di Vercel:**
1. Dashboard project → tab **Storage** → **Create Database** → pilih **Blob** → hubungkan ke project ini. Otomatis nambah env var `BLOB_READ_WRITE_TOKEN`.
2. Redeploy.

Fitur ini butuh login dulu (biar gak disalahgunakan orang random buat nge-spam storage), tapi link hasilnya bisa dibuka publik oleh siapa saja.
